Entpacken Sie zun�chst das ZIP-Archiv direkt nach H:\

... wechseln Sie anschlie�end in das Verzeichnis mysql\bin und erstellen Sie auf Ihrem Desktop eine Verkn�pfung auf folgende Dateien:

- mysql_Start_Server.bat
- mysql_Start_Console.bat
- mysql_Stop_Server.bat


anschlie�end starten Sie 
1) den Server
2) die Console

am Ende des Unterrichts stoppen Sie den Server mit mysql_Stop_server.bat oder der entsprechenden Verkn�pfung